/*
 * 6_Protocol.ino
 *
 * Serial protocol shell:
 *   1. Create the SerialCommands parser
 *   2. Register all serial commands
 *   3. Print HELP / HELP ALL / STATE
 *   4. Read serial input in protocolPoll()
 *
 * Command callbacks live in 7_Protocol_Commands.ino. The normal measurement
 * behavior lives in the 5*.ino files; debug behavior lives in Debugging.ino.
 *
 * How to add a serial command:
 *   1. Add this in 7_Protocol_Commands.ino:
 *        void cmdXxxCallback(SerialCommands *sender) { runCommand(sender, handleXxx); }
 *        void handleXxx() { ...actual behavior... }
 *   2. Create a SerialCommand below:
 *        SerialCommand cmdXxx("XXX", cmdXxxCallback);
 *   3. Add it in protocolBegin():
 *        serialCommands.AddCommand(&cmdXxx);
 *   4. Add a help line in printHelp() or printDebugHelp():
 *        out.println(F("CMD XXX"));
 *
 * Example: SWEEP maps to cmdSweep -> cmdSweepCallback() -> handleSweep().
 *          SWEEP_T lets students choose point count and sample delay.
 *          SWEEP_ALL / SWEEP_POINTS are debug views of formal sweep data.
 */

const size_t COMMAND_BUFFER_LEN = 160;
char commandBuffer[COMMAND_BUFFER_LEN];

SerialCommands serialCommands(&Serial, commandBuffer, sizeof(commandBuffer),
                              "\n", " ");

SerialCommand cmdHelp("HELP", cmdHelpCallback);
SerialCommand cmdPing("PING", cmdPingCallback);
SerialCommand cmdState("STATE", cmdStateCallback);
SerialCommand cmdIdle("IDLE", cmdIdleCallback);
SerialCommand cmdRelay("RELAY", cmdRelayCallback);
SerialCommand cmdAdc("ADC", cmdAdcCallback);
SerialCommand cmdAdcBoth("ADC_BOTH", cmdAdcBothCallback);
SerialCommand cmdAdcSpeed("ADC_SPEED", cmdAdcSpeedCallback);
SerialCommand cmdSpiHz("SPI_HZ", cmdSpiHzCallback);
SerialCommand cmdCal("CAL", cmdCalCallback);
SerialCommand cmdSetCal("SET_CAL", cmdSetCalCallback);
SerialCommand cmdVoc("VOC", cmdVocCallback);
SerialCommand cmdIsc("ISC", cmdIscCallback);
SerialCommand cmdVocTest("VOC_TEST", cmdVocTestCallback);
SerialCommand cmdIscTest("ISC_TEST", cmdIscTestCallback);
SerialCommand cmdSweep("SWEEP", cmdSweepCallback);
SerialCommand cmdSweepT("SWEEP_T", cmdSweepTCallback);
SerialCommand cmdSweepAll("SWEEP_ALL", cmdSweepAllCallback);
SerialCommand cmdSweepPoints("SWEEP_POINTS", cmdSweepPointsCallback);
SerialCommand cmdStop("STOP", cmdStopCallback);

void protocolBegin() {
  serialCommands.SetDefaultHandler(cmdUnknownCallback);

  // Basic and relay commands.
  serialCommands.AddCommand(&cmdHelp);
  serialCommands.AddCommand(&cmdPing);
  serialCommands.AddCommand(&cmdState);
  serialCommands.AddCommand(&cmdIdle);
  serialCommands.AddCommand(&cmdRelay);

  // ADC, SPI, and calibration commands.
  serialCommands.AddCommand(&cmdAdc);
  serialCommands.AddCommand(&cmdAdcBoth);
  serialCommands.AddCommand(&cmdAdcSpeed);
  serialCommands.AddCommand(&cmdSpiHz);
  serialCommands.AddCommand(&cmdCal);
  serialCommands.AddCommand(&cmdSetCal);
  serialCommands.AddCommand(&cmdVoc);
  serialCommands.AddCommand(&cmdIsc);

  // Test and sweep commands.
  serialCommands.AddCommand(&cmdVocTest);
  serialCommands.AddCommand(&cmdIscTest);
  serialCommands.AddCommand(&cmdSweep);
  serialCommands.AddCommand(&cmdSweepT);
  serialCommands.AddCommand(&cmdSweepAll);
  serialCommands.AddCommand(&cmdSweepPoints);
  serialCommands.AddCommand(&cmdStop);
}

void announceBoot() {
  Serial.println(F("Ready!"));
  Serial.println(F("OK BOOT name=IV_Swinger2_R4 hardware=SSR_MODULE protocol=SerialCommands baud=115200"));
  Serial.println(F("OK INFO send HELP for student commands, HELP ALL for debug commands"));
}

void protocolPoll() {
  SERIAL_COMMANDS_ERRORS status = serialCommands.ReadSerial();
  if (status == SERIAL_COMMANDS_ERROR_BUFFER_FULL) {
    Serial.println(F("ERR BUFFER_FULL command_too_long"));
  } else if (status == SERIAL_COMMANDS_ERROR_NO_SERIAL) {
    Serial.println(F("ERR SERIAL not_attached"));
  }
}

void printHelp(Stream &out, bool includeDebug) {
  out.println(F("OK HELP"));
  out.println(F("NOTE commands_and_ON_OFF_are_case_insensitive"));

  out.println(F("GROUP student"));
  out.print(F("CMD SWEEP  -> auto IV curve, max_points="));
  out.println(MAX_IV_POINTS);
  out.print(F("CMD SWEEP_T <points<="));
  out.print(MAX_RAW_POINTS);
  out.println(F("> <sample_delay_us<=1000>  -> manual teaching scan"));
  out.print(F("CMD VOC  -> open-circuit voltage, samples="));
  out.println(VOC_SAMPLE_COUNT);
  out.print(F("CMD ISC  -> short-circuit current, samples="));
  out.println(VOC_SAMPLE_COUNT);
  out.println(F("CMD STATE"));
  out.println(F("CMD IDLE"));
  out.println(F("CMD HELP ALL  -> show teacher/debug commands"));

  if (includeDebug) {
    printDebugHelp(out);
  }

  out.println(F("END_HELP"));
}

void printDebugHelp(Stream &out) {
  out.println(F("GROUP basic_debug"));
  out.println(F("CMD PING"));
  out.println(F("CMD RELAY <1|2|3> <ON|OFF|1|0>"));

  out.println(F("GROUP adc_and_calibration"));
  out.println(F("CMD ADC <0|1> [count]"));
  out.println(F("CMD ADC_BOTH [count]"));
  out.println(F("CMD ADC_SPEED [count]"));
  out.println(F("CMD SPI_HZ <1000000..4000000>"));
  out.println(F("CMD CAL"));
  out.println(F("CMD SET_CAL <name> <value>"));

  out.println(F("GROUP tests"));
  out.println(F("CMD VOC_TEST [count]"));
  out.println(F("CMD ISC_TEST [samples<=1000] [settle_ms<=200]"));

  out.println(F("GROUP sweep_debug"));
  out.print(F("CMD SWEEP_ALL  -> readable auto-sweep summary, max_points="));
  out.println(MAX_IV_POINTS);
  out.println(F("CMD SWEEP_POINTS  -> detailed CSV points from last sweep"));
  out.println(F("CMD STOP"));
}

void printState(Stream &out) {
  out.print(F("STATE spi_hz="));
  out.print(configSpiHz);
  out.print(F(" min_isc_adc="));
  out.print(min_isc_adc);
  out.print(F(" isc_stable_adc="));
  out.print(isc_stable_adc);
  out.print(F(" adc_ref="));
  out.print(adcReferenceVolts, 4);
  out.print(F(" v_scale="));
  out.print(voltageScale, 6);
  out.print(F(" i_scale="));
  out.print(currentScale, 6);
  out.println();
  printRelayState(out);
}
