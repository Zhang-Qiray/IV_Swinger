/*
 * 8_Utils.ino
 *
 * Small utility functions: read the next argument, parse numbers, and parse ON/OFF.
 * These helpers do not control hardware directly; they only serve serial commands.
 */

// ---------------------------------------------------------------------------
// Serial command arguments
// ---------------------------------------------------------------------------

char *nextArg() {
  return activeCommand ? activeCommand->Next() : nullptr;
}

// ---------------------------------------------------------------------------
// Text switch and channel parsing
// ---------------------------------------------------------------------------

bool equalsIgnoreCase(const char *a, const char *b) {
  return strcasecmp(a, b) == 0;
}

bool parseOnOff(const char *text, bool *value) {
  if (!text) {
    return false;
  }
  if (equalsIgnoreCase(text, "ON") || strcmp(text, "1") == 0) {
    *value = true;
    return true;
  }
  if (equalsIgnoreCase(text, "OFF") || strcmp(text, "0") == 0) {
    *value = false;
    return true;
  }
  return false;
}

bool parseChannel(const char *text, int *channel) {
  return parseIntInRange(text, ADC_VOLTAGE_CH, ADC_CURRENT_CH, channel);
}

// ---------------------------------------------------------------------------
// Number parsing
// ---------------------------------------------------------------------------

bool parseIntInRange(const char *text, int minValue, int maxValue, int *value) {
  if (!text || !*text) {
    return false;
  }

  char *end = nullptr;
  const long parsed = strtol(text, &end, 10);
  if (*end != '\0' || parsed < minValue || parsed > maxValue) {
    return false;
  }

  *value = static_cast<int>(parsed);
  return true;
}

bool parseUint32InRange(const char *text, uint32_t minValue,
                        uint32_t maxValue, uint32_t *value) {
  if (!text || !*text || text[0] == '-') {
    return false;
  }

  char *end = nullptr;
  const unsigned long parsed = strtoul(text, &end, 10);
  if (*end != '\0' || parsed < minValue || parsed > maxValue) {
    return false;
  }

  *value = static_cast<uint32_t>(parsed);
  return true;
}

bool parseFloatValue(const char *text, float *value) {
  if (!text || !*text) {
    return false;
  }

  char *end = nullptr;
  const float parsed = strtod(text, &end);
  if (*end != '\0') {
    return false;
  }

  *value = parsed;
  return true;
}

bool parseCountOrReport(Stream &out, const char *text, int fallback,
                        int minValue, int maxValue, int *value,
                        const __FlashStringHelper *name) {
  if (!text) {
    *value = fallback;
    return true;
  }

  if (parseIntInRange(text, minValue, maxValue, value)) {
    return true;
  }

  out.print(F("ERR BAD_ARG "));
  out.print(name);
  out.print(F("_range_"));
  out.print(minValue);
  out.print(F("_"));
  out.println(maxValue);
  return false;
}

// ---------------------------------------------------------------------------
// Calibration parameters
// ---------------------------------------------------------------------------

bool setCalibrationValue(const char *name, float value) {
  if (equalsIgnoreCase(name, "adc_ref")) {
    adcReferenceVolts = value;
  } else if (equalsIgnoreCase(name, "v_top")) {
    voltageDividerTopOhms = value;
  } else if (equalsIgnoreCase(name, "v_bottom")) {
    voltageDividerBottomOhms = value;
  } else if (equalsIgnoreCase(name, "i_feedback")) {
    currentAmpFeedbackOhms = value;
  } else if (equalsIgnoreCase(name, "i_ground")) {
    currentAmpGroundOhms = value;
  } else if (equalsIgnoreCase(name, "i_shunt")) {
    currentShuntOhms = value;
  } else if (equalsIgnoreCase(name, "series_ohms")) {
    seriesResistanceOhms = value;
  } else if (equalsIgnoreCase(name, "v_scale")) {
    voltageScale = value;
  } else if (equalsIgnoreCase(name, "v_offset")) {
    voltageOffset = value;
  } else if (equalsIgnoreCase(name, "i_scale")) {
    currentScale = value;
  } else if (equalsIgnoreCase(name, "i_offset")) {
    currentOffset = value;
  } else {
    return false;
  }
  return true;
}

void printCalibrationNames(Stream &out) {
  out.println(F("CAL_NAMES adc_ref v_top v_bottom i_feedback i_ground i_shunt series_ohms v_scale v_offset i_scale i_offset"));
}

void printCalibration(Stream &out) {
  out.print(F("CAL adc_ref="));
  out.print(adcReferenceVolts, 6);
  out.print(F(" v_top="));
  out.print(voltageDividerTopOhms, 2);
  out.print(F(" v_bottom="));
  out.print(voltageDividerBottomOhms, 2);
  out.print(F(" i_feedback="));
  out.print(currentAmpFeedbackOhms, 2);
  out.print(F(" i_ground="));
  out.print(currentAmpGroundOhms, 2);
  out.print(F(" i_shunt="));
  out.print(currentShuntOhms, 6);
  out.print(F(" series_ohms="));
  out.print(seriesResistanceOhms, 6);
  out.print(F(" v_scale="));
  out.print(voltageScale, 6);
  out.print(F(" v_offset="));
  out.print(voltageOffset, 6);
  out.print(F(" i_scale="));
  out.print(currentScale, 6);
  out.print(F(" i_offset="));
  out.println(currentOffset, 6);
}
