/*
 * 2_Config.ino
 *
 * Central firmware configuration.
 *
 * This file intentionally keeps all hardware mapping and tunable runtime
 * values together:
 *   1. UNO R4 pin assignments
 *   2. ADC / SPI channel settings
 *   3. Voltage and current conversion constants
 *   4. Shared sweep buffers and last-measurement state
 *
 * Hardware-control files should use these constants, not hard-coded pin
 * numbers or ADC channel numbers.
 */

// ---------------------------------------------------------------------------
// UNO R4 hardware pin map
// ---------------------------------------------------------------------------

// D0/D1 are the USB serial pins. They are listed here so the reserved pins are
// obvious when checking wiring, but the firmware does not configure them.
const uint8_t PIN_USB_RX = 0;       // D0, USB serial RX, reserved
const uint8_t PIN_USB_TX = 1;       // D1, USB serial TX, reserved

// IV Swinger 2 SSR module control outputs.
const uint8_t PIN_SSR1 = 2;         // Main PV-to-capacitor sweep switch
const uint8_t PIN_ONE_WIRE_BUS = 3; // Optional DS18B20 temperature sensor bus
const uint8_t PIN_SSR2 = 6;         // Capacitor bleed/discharge path
const uint8_t PIN_SSR3 = 7;         // Isc bypass around the load capacitors

// MCP3202 ADC chip-select. MOSI/MISO/SCK use the UNO R4 hardware SPI pins.
const uint8_t PIN_ADC_CS = 10;

// ---------------------------------------------------------------------------
// ADC / SPI configuration
// ---------------------------------------------------------------------------

// ADC / SPI
const uint8_t ADC_VOLTAGE_CH = 0;   // MCP3202 CH0 measures panel voltage
const uint8_t ADC_CURRENT_CH = 1;   // MCP3202 CH1 measures shunt current
const int ADC_MAX = 4096;           // 12-bit ADC count range is 0..4095
const int ADC_SAT = 4095;           // Saturated 12-bit ADC reading
uint32_t configSpiHz = 4000000;     // Runtime SPI clock, adjustable by SPI_HZ

// ---------------------------------------------------------------------------
// ADC-count to real-unit conversion constants
// ---------------------------------------------------------------------------

// Hardware defaults. CAL prints them, and SET_CAL can temporarily adjust them
// at runtime for calibration tests. Resetting the board restores these values.
float adcReferenceVolts = 4.880;
float voltageDividerTopOhms = 150000.0;
float voltageDividerBottomOhms = 7500.0;
float currentAmpFeedbackOhms = 75000.0;
float currentAmpGroundOhms = 1000.0;
float currentShuntOhms = 0.005;
float seriesResistanceOhms = 0.0;

// Final linear calibration:
//   displayed_value = raw_converted_value * scale + offset
float voltageScale = 1.0057566;
float voltageOffset = 0.0386691;
float currentScale = 0.9461348;
float currentOffset = 0.1089526;

// ---------------------------------------------------------------------------
// Isc stability check
// ---------------------------------------------------------------------------

// A short-circuit current sample is considered useful only when it rises above
// the measured current-channel noise floor by at least min_isc_adc counts.
int min_isc_adc = 100;
int max_isc_poll = 5000;
int isc_stable_adc = 5;

// ---------------------------------------------------------------------------
// Shared sweep data
// ---------------------------------------------------------------------------

struct RawPoint {
  uint16_t v;
  uint16_t i;
};

const int VOC_COUNT_BUCKETS = ADC_MAX;
const int MAX_RAW_POINTS = 2500;

union ScratchBuffer {
  uint16_t vocCounts[VOC_COUNT_BUCKETS];
  RawPoint rawPoints[MAX_RAW_POINTS];
};

ScratchBuffer scratch;

int lastVocLoops = 0;
int lastVocAdc = 0;
uint16_t lastVocCount = 0;
int lastNoiseMin = ADC_SAT;
int lastNoiseMax = 0;

bool lastIscStable = false;
int lastIscLoops = 0;
int lastIscAdc = 0;
RawPoint lastIscStablePoints[3];
