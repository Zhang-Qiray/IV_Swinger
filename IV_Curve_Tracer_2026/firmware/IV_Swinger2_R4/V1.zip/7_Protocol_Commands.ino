/*
 * 7_Protocol_Commands.ino
 *
 * Daily-use serial command handlers live in this file.
 *
 * Suggested reading order:
 *   1. SerialCommands callbacks: cmdXXXCallback only forwards to handleXXX.
 *   2. Student/basic commands: HELP, STATE, IDLE, STOP.
 *   3. Measurement commands live with the sweep flow in 5_SWEEP.ino.
 *   4. Debug/test command handlers are grouped in Debugging.ino.
 *
 * VOC / ISC / SWEEP / SWEEP_T handlers are in 5_SWEEP.ino because they share
 * the same measurement setup.
 */

SerialCommands *activeCommand = nullptr;

// ---------------------------------------------------------------------------
// SerialCommands callbacks: forward only, no command behavior here.
// ---------------------------------------------------------------------------

void runCommand(SerialCommands *sender, void (*handler)()) {
  activeCommand = sender;
  handler();
  activeCommand = nullptr;
}

void cmdUnknownCallback(SerialCommands *sender, const char *command) {
  sender->GetSerial()->print(F("ERR UNKNOWN_COMMAND cmd="));
  sender->GetSerial()->println(command);
}

void cmdHelpCallback(SerialCommands *sender) {
  runCommand(sender, handleHelp);
}

void cmdPingCallback(SerialCommands *sender) {
  runCommand(sender, handlePing);
}

void cmdStateCallback(SerialCommands *sender) {
  runCommand(sender, handleState);
}

void cmdIdleCallback(SerialCommands *sender) {
  runCommand(sender, handleIdle);
}

void cmdRelayCallback(SerialCommands *sender) {
  runCommand(sender, handleRelay);
}

void cmdAdcCallback(SerialCommands *sender) {
  runCommand(sender, handleAdc);
}

void cmdAdcBothCallback(SerialCommands *sender) {
  runCommand(sender, handleAdcBoth);
}

void cmdAdcSpeedCallback(SerialCommands *sender) {
  runCommand(sender, handleAdcSpeed);
}

void cmdSpiHzCallback(SerialCommands *sender) {
  runCommand(sender, handleSpiHz);
}

void cmdCalCallback(SerialCommands *sender) {
  runCommand(sender, handleCal);
}

void cmdSetCalCallback(SerialCommands *sender) {
  runCommand(sender, handleSetCal);
}

void cmdVocCallback(SerialCommands *sender) {
  runCommand(sender, handleVoc);
}

void cmdIscCallback(SerialCommands *sender) {
  runCommand(sender, handleIsc);
}

void cmdVocTestCallback(SerialCommands *sender) {
  runCommand(sender, handleVocTest);
}

void cmdIscTestCallback(SerialCommands *sender) {
  runCommand(sender, handleIscTest);
}

void cmdSweepCallback(SerialCommands *sender) {
  runCommand(sender, handleSweep);
}

void cmdSweepTCallback(SerialCommands *sender) {
  runCommand(sender, handleSweepT);
}

void cmdSweepAllCallback(SerialCommands *sender) {
  runCommand(sender, handleSweepAll);
}

void cmdSweepPointsCallback(SerialCommands *sender) {
  runCommand(sender, handleSweepPoints);
}

void cmdStopCallback(SerialCommands *sender) {
  runCommand(sender, handleStop);
}

// ---------------------------------------------------------------------------
// Student/basic commands: start here for daily use.
// ---------------------------------------------------------------------------

void handleHelp() {
  char *mode = nextArg();
  printHelp(Serial, mode && equalsIgnoreCase(mode, "ALL"));
}

void handleState() {
  printState(Serial);
}

void handlePing() {
  Serial.println(F("OK PONG"));
}

void handleIdle() {
  setIdleState();
  Serial.println(F("OK IDLE"));
  printState(Serial);
}

void handleStop() {
  setIdleState();
  Serial.println(F("OK STOP"));
  printState(Serial);
}
